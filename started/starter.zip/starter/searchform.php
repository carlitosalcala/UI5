<form role="form" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>" >
    <input type="text" value="" name="s" id="s" class="form-control" placeholder="Search" autocomplete="off" />
</form>